<?php

namespace UltraPlugins;

use UltraPlugins\DonateCases;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\math\Vector3;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\Player;

class DonateEvents extends PluginBase implements Listener {
	public function __construct(DonateCases $plugin){
		$this->plugin = $plugin;
	}

	public function onCaseJoin(PlayerJoinEvent $e){
		if($this->plugin->getConfig()->getAll()["particle"]["enabled"] == "yes"){
			$p = $e->getPlayer();
			$indent = 0;
			foreach($this->plugin->getConfig()->getAll()["particle"]["text"] as $text){
 				$p->getLevel()->addParticle(new FloatingTextParticle(new Vector3($this->plugin->getConfig()->getAll()["block"]["x"] + $this->plugin->getConfig()->getAll()["particle"]["+x"], $this->plugin->getConfig()->getAll()["block"]["y"] + $this->plugin->getConfig()->getAll()["particle"]["+y"] - $indent, $this->plugin->getConfig()->getAll()["block"]["z"] + $this->plugin->getConfig()->getAll()["particle"]["+z"]), "", str_replace(["{CASES}", "{OPEN}"], [$this->plugin->getCases($p), $this->plugin->getOpens($p)], $text)), array($p));
				$indent = $indent + $this->plugin->getConfig()->getAll()["particle"]["indent"];
 			}
		}
	}

	public function onCaseOpen(PlayerInteractEvent $e){
		if($this->plugin->getConfig()->getAll()["block"]["enabled"] == "yes"){
			$p = $e->getPlayer();
			$b = $e->getBlock();
			if(round($b->getX()) == $this->plugin->getConfig()->getAll()["block"]["x"] && round($b->getY()) == $this->plugin->getConfig()->getAll()["block"]["y"] && round($b->getZ()) == $this->plugin->getConfig()->getAll()["block"]["z"]){
				$e->setCancelled();
				if($this->plugin->getCases($p) > 0){
					$this->plugin->reduceCases($p, 1);
					$this->plugin->addOpen($p);

					$groups = $this->plugin->groups->getAll();
					$group = array_rand($groups, 1);
 
					foreach($this->plugin->getConfig()->getAll()["msg"]["open"] as $open){
						$p->sendMessage(str_replace(["{GROUP}", "{PRICE}"], [$group, $groups[$group]], $open));
					}

					$this->groups[strtolower($p->getName())] = $group;
					$this->price[strtolower($p->getName())] = $groups[$group];
 
 				}else{
					foreach($this->plugin->getConfig()->getAll()["msg"]["noopen"] as $noopen){
						$p->sendMessage($noopen);
 					}
				}
			}
		}
	}

 }

?>