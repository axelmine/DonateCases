<?php

namespace UltraPlugins;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\Player;
 
class DonateCases extends PluginBase {
	public $keys, $opens, $groups, $commands, $PurePerms;

	public function onEnable(){
		@mkdir($this->getDataFolder());
	   @mkdir($this->getDataFolder()."keys/");		
		$this->saveDefaultConfig();
 		$this->keys = new Config($this->getDataFolder()."keys/keys.json", Config::JSON);
 		$this->opens = new Config($this->getDataFolder()."keys/opens.json", Config::JSON);
		$this->groups = new Config($this->getDataFolder(). "groups.yml", Config::YAML, ["Admin" => 10, "OP" => 20, "Owner" => 100]);
		$this->commands = new Config($this->getDataFolder(). "commands.yml", Config::YAML, ["main" => "dc", "other" => ["help" => "help", "group" => "group", "open" => "open", "see" => "see", "pay" => "pay", "give" => "give"]]);

 		$this->getServer()->getPluginManager()->registerEvents(new DonateEvents ($this), $this);
 		$this->PurePerms = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
		if($this->PurePerms){
			$this->getLogger()->info("§6Найден плагин на права §aPurePerms");
 		}else{
			$this->getLogger()->info("§6Не найден плагин на права");
			$this->getServer()->getPluginManager()->disablePlugin($this);
		}

		if($this->getServer()->getCommandMap()->getCommand($this->commands->get("dc")) !== null){
			$this->getServer()->getCommandMap()->getCommand($this->commands->get("dc"))->setLabel($this->commands->get("dc")."__");
 			$this->getServer()->getCommandMap()->getCommand($this->commands->get("dc"))->unregister($this->getServer()->getCommandMap());
		}
		$this->getServer()->getCommandMap()->register("[".$this->commands->get("dc")."]", new Commands\DcCmd ($this));
		$this->getLogger()->info("§6Плагин §cAdvanced§3Donate§2Cases §6активирован!");
	}

	public function onDisable(){
		$this->getLogger()->info("§6Плагин §cAdvanced§3Donate§2Cases §6дезактивирован!");
	}

	public function getCases($player){
		if($player instanceof Player){
			if($this->keys->exists(strtolower($player->getName()))){
				$cases = $this->keys->get(strtolower($player->getName()));
			}else{
				$cases = "0";
			}
			return $cases;
		}else{
			if($this->keys->exists(strtolower($player))){
				$cases = $this->keys->get(strtolower($player));
			}else{
				$cases = "0";
			}
			return $cases;
		}
	}

	public function getOpens($player){
		if($player instanceof Player){
			if($this->opens->exists(strtolower($player->getName()))){
				$opens = $this->opens->get(strtolower($player->getName()));
			}else{
				$opens = "0";
			}
			return $opens;
		}else{
			if($this->opens->exists(strtolower($player))){
				$opens = $this->opens->get(strtolower($player));
			}else{
				$opens = "0";
			}
			return $opens;
		}
	}

	public function addCases($player, $count){
		if($player instanceof Player){
			if($this->keys->exists(strtolower($player->getName()))){
				$this->keys->set(strtolower($player->getName()), $this->keys->get(strtolower($player->getName())) + $count);
				$this->keys->save();
			}else{
				$this->keys->set(strtolower($player->getName()), $count);
				$this->keys->save();
			}
		}else{
			if($this->keys->exists(strtolower($player))){
				$this->keys->set(strtolower($player), $this->keys->get(strtolower($player)) + $count);
				$this->keys->save();
			}else{
				$this->keys->set(strtolower($player), $count);
				$this->keys->save();
			}
		}
	}

	public function addOpen($player){
		if($player instanceof Player){
			if($this->opens->exists(strtolower($player->getName()))){
				$this->opens->set(strtolower($player->getName()), $this->opens->get(strtolower($player->getName())) + 1);
				$this->opens->save();
			}else{
				$this->opens->set(strtolower($player->getName()), 1);
				$this->opens->save();
			}
		}else{
			if($this->opens->exists(strtolower($player))){
				$this->opens->set(strtolower($player), $this->opens->get(strtolower($player)) + 1);
				$this->opens->save();
			}else{
				$this->opens->set(strtolower($player), 1);
				$this->opens->save();
			}
		}
	}

	public function reduceCases($player, $count){
		if($player instanceof Player){
			if($this->keys->exists(strtolower($player->getName()))){
				$keys = $this->keys->get(strtolower($player->getName()));
 				if($keys - $count <= 0){
					$this->keys->remove(strtolower($player->getName()));
					$this->keys->save();
 				}else{
					$this->keys->set(strtolower($player->getName()), $keys - $count);
					$this->keys->save();
				}
			}
		}else{
			if($this->keys->exists(strtolower($player))){
				$keys = $this->keys->get(strtolower($player));
 				if($keys - $count <= 0){
					$this->keys->remove(strtolower($player));
					$this->keys->save();
 				}else{
					$this->keys->set(strtolower($player), $keys - $count);
					$this->keys->save();
				}
			}
		}
	}

}

?>