<?php

namespace UltraPlugins\Commands;

use UltraPlugins\DonateCases;
use pocketmine\command\Command;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecuter;
use pocketmine\Player;
use pocketmine\Server;

class DcCmd extends Command {
	public function __construct(DonateCases $plugin){
		$this->plugin = $plugin;
		parent::__construct("dc", "Донат-Кейсы", "/dc", array("dc"));
	}

	public function execute(CommandSender $sender, $alias, array $args){
		if(!isset($args[0])){
			$sender->sendMessage($this->plugin->getConfig()->getAll()["usage"]["help"]);
			return true;
		}
		switch(strtolower($args[0])){
			case $this->plugin->commands->getAll()["other"]["group"]:
				if(isset($this->groups[strtolower($sender->getName())])){
					$this->plugin->PurePerms->getUserDataMgr()->setGroup($sender, $this->plugin->PurePerms->getGroup($this->groups[strtolower($sender->getName())]), null);
					foreach($this->plugin->getConfig()->getAll()["msg"]["group"] as $give){
						$sender->sendMessage(str_replace("{GROUP}", $this->groups[strtolower($sender->getName())], $give));
					}
					if($this->plugin->getConfig()->getAll()["broadcast"]["enabled"] == "yes"){
						foreach($this->plugin->getConfig()->getAll()["broadcast"]["notice"] as $notice){
						$this->plugin->getServer()->broadcastMessage(str_replace(["{NICK}", "{GROUP}", "{PRICE}"], [$sender->getName(), $this->groups[strtolower($sender->getName())], $this->price[strtolower($sender->getName())]], $notice));
						}
					}
					unset($this->groups[strtolower($sender->getName())]);
					unset($this->price[strtolower($sender->getName())]);
				}else{
					foreach($this->plugin->getConfig()->getAll()["msg"]["nogroup"] as $group){
						$sender->sendMessage($group);
					}
				}
				break;

 				case $this->plugin->commands->getAll()["other"]["help"]:
					foreach($this->plugin->getConfig()->getAll()["msg"]["help"] as $help){
						$sender->sendMessage(str_replace(["{CASES}", "{OPEN}"], [$this->plugin->getCases($sender), $this->plugin->getOpens($sender)], $help));
					}
 				break;

				case $this->plugin->commands->getAll()["other"]["open"]:
					if($this->plugin->getCases($sender) > 0){
						$this->plugin->reduceCases($sender, 1);
						$this->plugin->addOpen($sender);

						$groups = $this->plugin->groups->getAll();
						$group = array_rand($groups, 1);
 
						foreach($this->plugin->getConfig()->getAll()["msg"]["open"] as $open){
							$sender->sendMessage(str_replace(["{GROUP}", "{PRICE}"], [$group, $groups[$group]], $open));
						}

						$this->groups[strtolower($sender->getName())] = $group;
						$this->price[strtolower($sender->getName())] = $groups[$group];
 
 					}else{
						foreach($this->plugin->getConfig()->getAll()["msg"]["noopen"] as $noopen){
							$sender->sendMessage($noopen);
 						}
					}
					break;

					case $this->plugin->commands->getAll()["other"]["pay"]:
						if(count($args) < 3){
							$sender->sendMessage($this->plugin->getConfig()->getAll()["usage"]["pay"]["count"]);
							return true;
						}
						if(!is_numeric($args[2])){
							$sender->sendMessage($this->plugin->getConfig()->getAll()["usage"]["pay"]["num"]);
							return true;
						}
						if($args[2] <= 0){
							$sender->sendMessage($this->plugin->getConfig()->getAll()["usage"]["pay"]["num"]);
							return true;
						}
						if(($player = $this->plugin->getServer()->getPlayer($args[1])) != null){
							if($this->plugin->getCases($sender) < $args[2]){
								foreach($this->plugin->getConfig()->getAll()["msg"]["nopay"] as $nopay){
									$sender->sendMessage($nopay);
								}
								return true;
							}
							foreach($this->plugin->getConfig()->getAll()["msg"]["pay"] as $pay){
								$sender->sendMessage(str_replace(["{CASES}", "{NICK}"], [$args[2], $player->getName()], $pay));
							}
							foreach($this->plugin->getConfig()->getAll()["msg"]["recived"] as $recived){
								$player->sendMessage(str_replace(["{CASES}", "{NICK}"], [$args[2], $sender->getName()], $recived));
							}
							$this->plugin->addCases($player, $args[2]);
							$this->plugin->reduceCases($sender, $args[2]);
						}else{
							$sender->sendMessage($this->plugin->getConfig()->getAll()["msg"]["offline"]);
						}
						break;

						case $this->plugin->commands->getAll()["other"]["see"]:
							if($sender->hasPermission($this->plugin->getConfig()->getAll()["permissions"]["see"])){
								foreach($this->plugin->getConfig()->getAll()["msg"]["see"] as $see){
									$sender->sendMessage(str_replace(["{CASES}", "{OPEN}", "{NICK}"], [$this->plugin->getCases($args[1]), $this->plugin->getOpens($args[1]), $args[1]], $see));
								}
							}
							break;

							case $this->plugin->commands->getAll()["other"]["give"]:
								if($sender->hasPermission($this->plugin->getConfig()->getAll()["permissions"]["give"])){
									if(count($args) < 3){
										$sender->sendMessage($this->plugin->getConfig()->getAll()["usage"]["give"]);
										return true;
									}
									if(!is_numeric($args[2]) || $args[2] == 0 || $args[2] < 0){
										$sender->sendMessage("§c".$args[2]." - не допустимое значение");
										return true;
									}
									$this->plugin->addCases(strtolower($args[1]), $args[2]);
									foreach($this->plugin->getConfig()->getAll()["msg"]["give"] as $give){
 									$sender->sendMessage(str_replace(["{CASES}", "{NICK}"], [$args[2], $args[1]], $give));
									}
								}
								break;

								default:
								$sender->sendMessage($this->plugin->getConfig()->getAll()["usage"]["help"]);
								break;
							}
						}

					}

					?>